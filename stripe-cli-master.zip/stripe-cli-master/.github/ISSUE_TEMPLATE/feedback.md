---
name: Feedback
about: Provide free-form feedback on the CLI
title: ''
labels: ''
assignees: ''

---

### Feedback
_Give us free-form feedback on the CLI. Tell us what you're building, what you're trying to do with the CLI, features you'd like to see, areas that the CLI helps, areas where it needs improvement, anything confusing you saw, etc._

_Feedback can be completely freeform and stream of consciousness! If you prefer to submit private feedback, we have a form setup to do that: https://stri.pe/cli-feedback_
