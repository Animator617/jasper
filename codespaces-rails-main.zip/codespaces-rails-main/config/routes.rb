Rails.application.routes.draw do
  root "hello#index"
end
