interface Window {
	EdqConfig?: EdqConfigObject;
	sfccConfig?: SfccConfigObject;
}