#Introduction 
Experian Data Quality's cartridge for Demandware.

For testing files; intern is the one used by Experian.

To start your testings you need to install some dependencies in the "tests" folder:
* npm install intern
* npm install npx

For testing:
* Open a command prompt in "tests" folder
* Go to the next "tests" folder. (cd tests)
* Write the command "npx intern"
