package net.sf.click.ajax4click.examples.page;

public class HomePage extends BorderPage {

    public String title = "Home";

}
