Click.jq.lang={
    noCssSelector:"ERROR: Geen CSS selector gevind. 'n CSS selector specifiseer watter element om te ajaxify",
    unknownError:"Netwerk probleem",
    status404:"Gevraagde URL nie gevind nie.",
    status500:"Interne Server Fout.",
    parseError:"Fout. \nRequest persing het 'n fout.",
    timeoutError:"Request het verval.",
    defaultError:"Jammer, daar was 'n fout.",
    sessionTimeoutError:'Jou sessie het verval. Jy sal weer moet aanteken en word dan weer hierheen gebring.'
}