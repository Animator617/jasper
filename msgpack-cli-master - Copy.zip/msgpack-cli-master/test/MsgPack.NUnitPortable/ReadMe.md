﻿This is portable library version of subset of NUnit for MsgPack unit testing.
This library includes:
* Various `IResolveConstraints` including `Is`, `Not`, `Null`, etc.
* `Assert.That`.
* `TestPlatformAdapter` which invokes platform specific behavior like  `Assert.Fail()`.