
# executes core.py and visuals/tests for battleship_ai and tests